%Assignment-2-3_Q1(c)
%Name: Ajinkya Anil Dudhal
%Entry No: 2021EEM1001

%%%%%%%%%%%%%%%% Effect of noise distribution on the error %%%%%%%%%%%%%%%
%As we can see in the command window, I have calculated the variance of
%error for output without noise and for noisy output due to Uniformly
%distributed noise and AWGN noise. The variance of error in output due to AWGN noise
%is slightly higher as compared to the variance of output due to uniform noise.

clc;
clear;
close all;

num = xlsread('data_for_system_identification.xlsx');
u=num(:,1);                         %Input vector
step_size=0.5;

%%%%%%%%%%%%%%%%%%%%%%% Uniformly Distributed Noise %%%%%%%%%%%%%%%%%%%%%%
%For output without noise
m=0;
iteration=zeros([1000,1]);
w=zeros([1000,1]);                  %Weight vector intialization
y=zeros([1000,1]);                  %Output vector initialization
e=zeros([1000,1]);                  %Error vector initialization
d1=num(:,2);                        %Without noise desired output vector
uni_noise=rand(1,1000);
for i=1:1000
    iteration(i)=i;
    w(i)=m;
    y(i)=m*u(i)+uni_noise(i);
    e(i)=d1(i)-y(i);
    m=m+step_size*u(i)*e(i);        %Weight update Equation for LMS Algorithm
end
err_uni_noise=e;
fprintf('Variance of Error due to addition of Uniformly distributed noise for output without noise= %f\n\n',var(err_uni_noise));
subplot(4,1,1);
plot(iteration,abs(e),'blue');
title('For without noise');
legend('Error for Uniform noise');

%Noisy output
m=0;
iteration=zeros([1000,1]);
w=zeros([1000,1]);                  %Weight vector intialization
y=zeros([1000,1]);                  %Output vector initialization
e=zeros([1000,1]);                  %Error vector initialization
d2=num(:,3);                        %Without noise desired output vector
for i=1:1000
    iteration(i)=i;
    w(i)=m;
    y(i)=m*u(i)+uni_noise(i);
    e(i)=d2(i)-y(i);
    m=m+step_size*u(i)*e(i);        %Weight update Equation for LMS Algorithm
end
err_uni_noise=e;
fprintf('Variance of Error due to addition of Uniformly distributed noise for noisy output= %f\n\n',var(err_uni_noise));
subplot(4,1,2);
plot(iteration,abs(e),'red');
title('For noisy output');
legend('Error for Uniform noise');

%%%%%%%%%%%%%%%%%%%%% Addtitive White Gaussian Noise %%%%%%%%%%%%%%%%%%%%%
%For output without noise
m=0;
iteration=zeros([1000,1]);
w=zeros([1000,1]);                  %Weight vector intialization
y=zeros([1000,1]);                  %Output vector initialization
e=zeros([1000,1]);                  %Error vector initialization
d1=num(:,2);                        %Without noise desired output vector
for i=1:1000
    iteration(i)=i;
    w(i)=m;
    y(i)=awgn(m*u(i),10);
    e(i)=d1(i)-y(i);
    m=m+step_size*u(i)*e(i);        %Weight update Equation for LMS Algorithm
end
err_AWGN=e;
fprintf('Variance of Error due to addition of AWGN for output without noise= %f\n\n',var(err_AWGN));
subplot(4,1,3);
plot(iteration,abs(e),'black');
title('For without noise');
legend('Error for AWGN');

%Noisy output
m=0;
iteration=zeros([1000,1]);
w=zeros([1000,1]);                  %Weight vector intialization
y=zeros([1000,1]);                  %Output vector initialization
e=zeros([1000,1]);                  %Error vector initialization
d2=num(:,3);                        %Without noise desired output vector
for i=1:1000
    iteration(i)=i;
    w(i)=m;
    y(i)=awgn(m*u(i),10);
    e(i)=d2(i)-y(i);
    m=m+step_size*u(i)*e(i);        %Weight update Equation for LMS Algorithm
end
err_AWGN=e;
fprintf('Variance of Error due to addition of AWGN for noisy output= %f\n\n',var(err_AWGN));
subplot(4,1,4);
plot(iteration,abs(e),'green');
title('For noisy output');
legend('Error for AWGN');