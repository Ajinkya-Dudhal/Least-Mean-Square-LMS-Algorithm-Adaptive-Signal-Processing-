%Assignment-2-3_Q1(b)
%Name: Ajinkya Anil Dudhal
%Entry No: 2021EEM1001

clc;
clear;
close all;

num = xlsread('data_for_system_identification.xlsx');
u=num(:,1);                         %Input vector
m=0;
iteration=zeros([1000,1]);
w=zeros([1000,1]);                  %Weight vector intialization
y=zeros([1000,1]);                  %Output vector initialization
e=zeros([1000,1]);                  %Error vector initialization

%For output without noise
step_size=[0.02,0.5,1];             %Three different values of Step-size
d1=num(:,2);                        %Without noise desired output vector
for j=1:3
    for i=1:1000
        iteration(i)=i;
        w(i)=m;
        y(i)=m*u(i);
        e(i)=d1(i)-y(i);
        m=m+step_size(j)*u(i)*e(i);     %Weight update Equation for LMS Algorithm
    end
    if(step_size(j)==0.5)               %Variance is calculated in command window
        fprintf('Variance of Error for output without noise= %f\n\n',var(e));
    end
    subplot(2,1,1);
    plot(iteration,abs(e));
    hold on;
    m=0;
    w=zeros([1000,1]);
    iteration=zeros([1000,1]);
    y=zeros([1000,1]);
    e=zeros([1000,1]);
end
title('Error plot for output without noise');
xlabel('Iterations');
ylabel('Magnitude of Error');
legend('Error for Step-size=0.02','Error for Step-size=0.7','Error for Step-size=1');
hold off;

%For noisy output
step_size=[0.05,0.5,0.56];
d2=num(:,3);                                %Noisy desired output vector
for j=1:3
    for i=1:1000
        iteration(i)=i;
        w(i)=m;
        y(i)=m*u(i);
        e(i)=d2(i)-y(i);
        m=m+step_size(j)*u(i)*e(i);         %Weight update Equation for LMS Algorithm
    end
    if(step_size(j)==0.5)                   %Variance is calculated in command window
        fprintf('Variance of Error for noisy output= %f\n\n',var(e));
    end
    subplot(2,1,2);
    plot(iteration,abs(e));
    hold on;
    m=0;
    w=zeros([1000,1]);
    iteration=zeros([1000,1]);
    y=zeros([1000,1]);
    e=zeros([1000,1]);
end
title('Error plot for noisy output');
xlabel('Iterations');
ylabel('Magnitude of Error');
legend('Error for Step-size=0.05','Error for Step-size=0.7','Error for Step-size=0.56');
hold off;