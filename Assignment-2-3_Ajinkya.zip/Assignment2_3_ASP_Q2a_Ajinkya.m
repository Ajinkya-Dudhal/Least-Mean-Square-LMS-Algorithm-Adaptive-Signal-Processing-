%Assignment-2-3_Q2(a)
%Name: Ajinkya Anil Dudhal
%Entry No: 2021EEM1001

clc;
clear;
close all;

num = xlsread('data_for_system_identification.xlsx');
u=num(:,1);                         %Input vector
delta=1;                            %Taking value of delta=1
v=u.^2+delta;
step_size=0.7;

%For output without noise
m=0;
iteration=zeros([1000,1]);
w=zeros([1000,1]);                  %Weight vector intialization
y=zeros([1000,1]);                  %Output vector initialization
e=zeros([1000,1]);                  %Error vector initialization
d1=num(:,2);                        %Without noise desired output vector
for i=1:1000
    iteration(i)=i;
    w(i)=m;
    y(i)=m*u(i);
    e(i)=d1(i)-y(i);
    m=m+(step_size/v(i))*u(i)*e(i);        %Weight update Equation for NLMS Algorithm
end
subplot(2,1,1);
plot(iteration,w);
title('For without noise');
xlabel('Iterations');
ylabel('Filter Coefficients');
legend('Filter Coefficients');

%Noisy output
m=0;
iteration=zeros([1000,1]);
w=zeros([1000,1]);                  %Weight vector intialization
y=zeros([1000,1]);                  %Output vector initialization
e=zeros([1000,1]);                  %Error vector initialization
d2=num(:,3);                        %Without noise desired output vector
for i=1:1000
    iteration(i)=i;
    w(i)=m;
    y(i)=m*u(i);
    e(i)=d2(i)-y(i);
    m=m+(step_size/v(i))*u(i)*e(i);        %Weight update Equation for NLMS Algorithm
end
subplot(2,1,2);
plot(iteration,w);
title('For noisy output');
xlabel('Iterations');
ylabel('Filter Coefficients');
legend('Filter Coefficients');